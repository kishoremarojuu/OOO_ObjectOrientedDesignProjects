package com.car.rent.domain;

public enum PaymentType {
	CREDITCARD, DEBITCARD, MASTERCARD
}
