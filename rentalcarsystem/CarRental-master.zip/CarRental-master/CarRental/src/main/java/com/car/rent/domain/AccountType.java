package com.car.rent.domain;

public enum AccountType {
	CUSTOMER,ADMIN
}
